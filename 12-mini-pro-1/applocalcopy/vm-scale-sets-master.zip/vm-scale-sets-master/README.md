# Azure VM Scale Sets
This repo is for managing Azure virtual machine scale sets, in particular preview programs, samples and issues.

> **Note**
> Please refer to the [official VMSS documentation](https://docs.microsoft.com/en-us/azure/virtual-machine-scale-sets/overview) for product documentation, feedback, etc.

