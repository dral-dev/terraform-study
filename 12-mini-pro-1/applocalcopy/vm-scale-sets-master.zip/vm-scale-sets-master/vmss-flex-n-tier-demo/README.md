# vmss-flex-cassandra-demo

This is a reimplementation of the [n-tier-cassandra reference architecture](https://github.com/mspnp/reference-architectures/tree/master/virtual-machines/n-tier-linux) with Virtual Machine Scale Sets with Flexible Orchestration
